##' @author: Yi Tang
##' @date: 2016-04-20 06:39:28

##'  yiR 
##'
##' my own pkgs 
##' @name yiR
##' @docType package
##' @import data.table ggplot2
NULL
