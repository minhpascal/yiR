===
yiR
===




My collection of handy R functions. 

.. toctree::
   :maxdepth: 2
   :caption: Documentation
   
   data_manipulation
   utilise
   visualisation
   gis
   evt
   distribution
   machine_learning
