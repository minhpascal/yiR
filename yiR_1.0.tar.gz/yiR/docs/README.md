[![Documentation Status](https://readthedocs.org/projects/yir/badge/?version=latest)](https://readthedocs.org/projects/yir/?badge=latest)
# yiR



My collection of handy R functions.